/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package armazenamento;

import java.util.ArrayList;
import modelo.Problema;

/**
 *
 * @author jc
 */
public class MeioArmazenamento {
    public static ArrayList<Problema> MEIO_ARMAZENAMENTO_PROBLEMAS = new ArrayList<>();
}
